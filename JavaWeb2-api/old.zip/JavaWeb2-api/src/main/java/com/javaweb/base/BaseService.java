package com.javaweb.base;

public class BaseService extends Base {

}
